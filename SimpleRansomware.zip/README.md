# Simple-Ransomware
------------------
SIMPLE RANSOMWARE
------------------
Made by Glenix85
Written in C#

I suggest you to read this file (README.md) first before using this application. Just one mistake could 

I created this application just for education to everyone and for testing purposes only.
Please DO NOT use for prank and evil purposes.
The creator of this application is not responsible for any damages to your PC.
To run it, make sure .NET Framework 6.0 is installed on your computer.
To minimize the risk, run it in a virtual machine.

How to use it:
1. Type a valid directory file that you want to encrypt (Oh yeah, btw you cannot encrypt a folder).
2. Click "Encrypt" button to encrypt the file you want to encrypt.
3. Make sure that is the file you want to encrypt. If yes, click "Yes" button. If no, click "No" button.
4. After that, your file that you want to encrypt will be encrypted in just a second.
5. To decrypt it, type a valid password. The password is "yondaktaukoktanyasaya".
6. Click "Yes" button to continue.
7. Your file is decrypted.
8. To close the application, make sure that all the files that have been used as a test for this application have been decrypted. Because if you don't do it, you could lose some files that you have not decrypted them yet.
9. But if you've already done it, you can visit this directory (C:\Program Files). But it is a bit difficult to distinguish one file from another.
