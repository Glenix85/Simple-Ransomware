------------------
SIMPLE RANSOMWARE
------------------

Made by Glenix85
Written in C#

I suggest you to read this file first before using SimpleRansomware.
I created this app just for education to everyone and for testing purposes only.
Please DO NOT use it for praank and evil purposes.
The creator of this application is not responsible for any damages to your PC.
To run it, make sure .NET Framework 6.0 or higher is installed on your PC and please run it as administrator or some features might not working due to your PC's security.
To minimize the risk, run it in a virtual machine.

How to use it:
1. Type a valid directory file that you want to encrypt(Btw, you cannot encrypt any folders)
2. Click "Encrypt" button to encrypt it.
3. Make sure that is the file you want to encrypt. If yes, click "Yes" button. If no, click "No" button.
4. After that, your file that you want to encrypt is encrypted in just a second.
5. To decrypt it, type a valid password. The password is "yondaktaukoktanyasaya". 
6. Click "Decrypt" button to decrypt your file and click "Yes" to continue.
7. Your file is decrypted.
8. To close this app, make sure all the files that have been used as a test for this app has been decrypted. If you don't do it, you could lose some files that you haven't decrypted them yet.
9. But if you already done it, you can visit this directory (C:\Program Files). But it's a bit difficult to distinguish one file from another.